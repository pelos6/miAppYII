<?php

return [
    'class' => 'yii\db\Connection',
//    'dsn' => 'mysql:host=localhost;dbname=yii2basic',
//    'username' => 'root',
//    'password' => '',
    'dsn' => 'mysql:host=localhost;dbname=javier',
    'username' => 'root',
    'password' => 'javier',
    'charset' => 'utf8',
];
