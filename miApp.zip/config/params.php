<?php

return [
    'title' => 'Mi App',
    'version' => '1.0.0',
    'adminEmail' => 'javieriranzo@hotmail.com',
];
